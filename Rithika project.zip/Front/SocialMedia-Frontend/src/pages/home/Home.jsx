import React from 'react'
import PostSide from '../../components/PostSide/PostSide'
import './Home.css'
const Home = () => {
  return (
    <div className="Home">
        <PostSide/>
        
    </div>
  )
}

export default Home